import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./Layout Component/Header";
import  Sidebar  from "./Layout Component/Sidebar";
import  Footer  from "./Layout Component/Footer";
import Dashboard from "./Components/dashboard";
import NoPage from "./Components/nopage";

function App() {
  return (
    
    <>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />}>
          <Route index element={<Dashboard />} />
          {/* <Route path="blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} /> */}
          <Route path="*" element={<NoPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
   <Header />
   <Dashboard/>
   <Footer/>
   <Sidebar/>
    </>
  );
}

export default App;
